# Skiplist

Goals: Working with dynamic arrays, pointers, doubly linked lists
